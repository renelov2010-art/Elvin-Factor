# فهرست منابع استخراج‌شده از آسان حساب فاکتور

- تعداد فایل‌های داخل ZIP اصلی: 3438
- تعداد چیدمان‌های XML: 229
- منابع مرجع قابل استفاده/بررسی در assets/original_reference: 64

## چیدمان‌های کلیدی
- `res/layout/activity_home1.xml`
- `res/layout/activity_hesab_home.xml`
- `res/layout/activity_riz_fact.xml`
- `res/layout/activity_pishfact.xml`
- `res/layout/activity_setting.xml`
- `res/layout/activity_full_rep_fact.xml`
- `res/layout/activity_srch_fact.xml`

> XMLهای ذخیره‌شده از APK باینری و کامپایل‌شده‌اند؛ برای تبدیل به سورس قابل ویرایش به decoder سازگار با Android resources نیاز است. فایل‌های اصلی در این پوشه برای بررسی و مرجع حفظ شده‌اند.
