package com.elvinfactor.app

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.graphics.drawable.GradientDrawable
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("elvin_factor", MODE_PRIVATE) }
    private val blue = Color.rgb(8, 55, 157)
    private val pale = Color.rgb(244, 247, 253)
    private val ink = Color.rgb(24, 39, 76)
    private val cyan = Color.rgb(0, 205, 245)
    private var page = "home"
    private val nf = NumberFormat.getNumberInstance(Locale("fa", "IR"))
    private val persianFont by lazy { try { Typeface.createFromAsset(assets, "fonts/yek_r.ttf") } catch (_: Exception) { Typeface.DEFAULT } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(5, 31, 105)
        window.navigationBarColor = Color.rgb(5, 31, 105)
        showSplash()
    }

    private fun rounded(color: Int, radius: Float = 22f): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = radius * resources.displayMetrics.density
    }

    private fun showSplash() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(24, 24, 24, 24)
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(0, 105, 255), Color.rgb(3, 20, 105), Color.rgb(0, 36, 145)))
        }
        val logo = TextView(this).apply {
            text = "▤↗"; textSize = 48f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(0, 190, 255), Color.rgb(0, 40, 220))).apply {
                cornerRadius = 34f * resources.displayMetrics.density
                setStroke((2 * resources.displayMetrics.density).toInt(), cyan)
            }
            elevation = 12f
        }
        root.addView(logo, LinearLayout.LayoutParams((126*resources.displayMetrics.density).toInt(), (126*resources.displayMetrics.density).toInt()))
        val title = TextView(this).apply { text = "الوین فاکتور"; textSize = 30f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setTypeface(persianFont, Typeface.BOLD); setPadding(0, 22, 0, 0) }
        root.addView(title)
        root.addView(TextView(this).apply { text = "Elvin Factor"; textSize = 17f; letterSpacing = .16f; setTextColor(cyan); gravity = Gravity.CENTER; setPadding(0, 2, 0, 0) })
        root.addView(TextView(this).apply { text = "مدیریت آسان کسب‌وکار شما"; textSize = 15f; setTextColor(Color.rgb(120, 225, 255)); gravity = Gravity.CENTER; setPadding(0, 12, 0, 26) })
        val progress = ProgressBar(this).apply { indeterminateTintList = android.content.res.ColorStateList.valueOf(cyan) }
        root.addView(progress, LinearLayout.LayoutParams((42*resources.displayMetrics.density).toInt(), (42*resources.displayMetrics.density).toInt()))
        setContentView(root)
        Handler(Looper.getMainLooper()).postDelayed({ showHome() }, 2300)
    }

    private fun base(title: String): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(pale)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val header = TextView(this).apply {
            text = title
            textSize = 21f
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
            setPadding(20, 18, 20, 18)
            setBackgroundColor(blue)
        }
        root.addView(header, LinearLayout.LayoutParams(-1, 64))
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 24)
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        return content
    }

    private fun txt(s: String, size: Float = 16f, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = s; textSize = size; setTextColor(ink)
            setTypeface(if (bold) Typeface.create(persianFont, Typeface.BOLD) else persianFont)
            gravity = Gravity.RIGHT
            setPadding(4, 8, 4, 8)
        }

    private fun btn(s: String, action: () -> Unit): Button =
        Button(this).apply {
            text = s; isAllCaps = false
            setTextColor(Color.WHITE); setBackgroundTintList(android.content.res.ColorStateList.valueOf(blue))
            setOnClickListener { action() }
        }

    private fun field(hint: String, value: String = "") = EditText(this).apply {
        this.hint = hint; setText(value); textSize = 16f
        typeface = persianFont
        gravity = Gravity.RIGHT
        setPadding(12, 10, 12, 10)
        layoutDirection = View.LAYOUT_DIRECTION_RTL
    }

    private fun addCard(parent: LinearLayout, title: String, subtitle: String, action: () -> Unit) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 12, 16, 12)
            setBackgroundColor(Color.WHITE)
            elevation = 2f
        }
        card.addView(txt(title, 18f, true))
        card.addView(txt(subtitle, 13f))
        card.setOnClickListener { action() }
        val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = 12
        parent.addView(card, lp)
    }

    private fun load(key: String): JSONArray = try { JSONArray(prefs.getString(key, "[]")) } catch (_: Exception) { JSONArray() }
    private fun save(key: String, arr: JSONArray) { prefs.edit().putString(key, arr.toString()).apply() }
    private fun money(n: Double) = nf.format(n) + " تومان"

    private fun showHome() {
        page = "home"
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(pale); layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(18, 14, 18, 14)
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.rgb(5, 36, 123), Color.rgb(0, 92, 205)))
        }
        val logo = TextView(this).apply { text = "▤↗"; textSize = 24f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); background = rounded(Color.rgb(0, 148, 245), 15f) }
        header.addView(logo, LinearLayout.LayoutParams((48*resources.displayMetrics.density).toInt(), (48*resources.displayMetrics.density).toInt()))
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12, 0, 12, 0) }
        brand.addView(TextView(this).apply { text = "الوین فاکتور"; textSize = 20f; setTextColor(Color.WHITE); typeface = Typeface.create(persianFont, Typeface.BOLD) })
        brand.addView(TextView(this).apply { text = "Elvin Factor"; textSize = 12f; setTextColor(Color.rgb(170, 225, 255)); letterSpacing = .08f })
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(TextView(this).apply { text = "☰"; textSize = 28f; setTextColor(Color.WHITE); setPadding(8, 0, 8, 0); setOnClickListener { showSettings() } })
        root.addView(header)
        val scroll = ScrollView(this)
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 16, 16, 22) }
        scroll.addView(c); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f)); setContentView(root)
        val invoices = load("invoices"); var total = 0.0
        for (i in 0 until invoices.length()) total += invoices.optJSONObject(i)?.optDouble("total", 0.0) ?: 0.0
        val summary = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(16, 14, 16, 14); background = rounded(Color.WHITE, 20f); elevation = 3f }
        val stats = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        stats.addView(txt("فروش ثبت‌شده", 14f, true).apply { setTextColor(Color.GRAY) })
        stats.addView(txt(money(total), 20f, true).apply { setTextColor(Color.rgb(0, 158, 91)) })
        stats.addView(txt("${nf.format(invoices.length())} فاکتور ثبت‌شده", 12f).apply { setTextColor(Color.GRAY) })
        summary.addView(stats, LinearLayout.LayoutParams(0, -2, 1f))
        summary.addView(TextView(this).apply { text = "▥"; textSize = 34f; setTextColor(Color.rgb(0, 170, 110)); gravity = Gravity.CENTER; background = rounded(Color.rgb(232, 250, 243), 30f) }, LinearLayout.LayoutParams((58*resources.displayMetrics.density).toInt(), (58*resources.displayMetrics.density).toInt()))
        c.addView(summary)
        c.addView(txt("دسترسی سریع", 18f, true).apply { setPadding(2, 20, 2, 12) })
        fun tileRow(items: List<Triple<String,String,()->Unit>>) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
            items.forEach { (label, icon, action) ->
                val tile = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(8, 13, 8, 13); background = rounded(Color.WHITE, 20f); elevation = 2f; setOnClickListener { action() } }
                tile.addView(TextView(this).apply { text = icon; textSize = 27f; gravity = Gravity.CENTER; setTextColor(blue) }, LinearLayout.LayoutParams(-1, (42*resources.displayMetrics.density).toInt()))
                tile.addView(TextView(this).apply { text = label; textSize = 13f; gravity = Gravity.CENTER; setTextColor(ink); typeface = Typeface.create(persianFont, Typeface.BOLD) })
                val lp = LinearLayout.LayoutParams(0, (102*resources.displayMetrics.density).toInt(), 1f); lp.setMargins(4, 4, 4, 4); row.addView(tile, lp)
            }
            c.addView(row)
        }
        tileRow(listOf(Triple("ثبت فاکتور", "▤＋") { showInvoiceEditor(null) }, Triple("پیش‌فاکتور", "▤") { showInvoiceEditor(null) }))
        tileRow(listOf(Triple("کالاها و خدمات", "□") { showSimpleList("products", "کالاها و خدمات", "نام کالا", "قیمت واحد") }, Triple("مشتریان", "♙") { showSimpleList("customers", "مشتریان", "نام مشتری", "شماره تماس") }))
        tileRow(listOf(Triple("حساب مشتری", "▣") { showSimpleList("customers", "حساب مشتری", "نام مشتری", "شماره تماس") }, Triple("گزارش‌ها", "▥") { showReports() }))
        tileRow(listOf(Triple("فاکتورها", "▧") { showInvoices() }, Triple("تنظیمات", "⚙") { showSettings() }))
        val welcome = TextView(this).apply { text = "به الوین فاکتور خوش آمدید\nهمه‌چیز برای مدیریت آسان کسب‌وکار شما"; textSize = 14f; gravity = Gravity.CENTER; setTextColor(blue); typeface = Typeface.create(persianFont, Typeface.BOLD); setPadding(12, 18, 12, 18); background = rounded(Color.rgb(226, 241, 255), 18f) }
        val lp = LinearLayout.LayoutParams(-1, -2); lp.topMargin = 12; c.addView(welcome, lp)
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(4, 8, 4, 8); setBackgroundColor(Color.WHITE); elevation = 8f }
        listOf("⌂\nخانه" to { showHome() }, "▧\nفاکتورها" to { showInvoices() }, "♙\nمشتریان" to { showSimpleList("customers", "مشتریان", "نام مشتری", "شماره تماس") }, "▥\nگزارشات" to { showReports() }, "•••\nبیشتر" to { showSettings() }).forEach { pair ->
            val t = TextView(this).apply { text = pair.first; textSize = 11f; gravity = Gravity.CENTER; setTextColor(blue); setTypeface(persianFont, Typeface.BOLD); setPadding(4, 2, 4, 2); setOnClickListener { pair.second() } }
            nav.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(nav)
    }

    private fun showSimpleList(key: String, title: String, firstHint: String, secondHint: String) {
        page = key
        val c = base(title)
        c.addView(btn("＋ افزودن") {
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(8, 4, 8, 4) }
            val name = field(firstHint)
            val detail = field(secondHint)
            box.addView(name); box.addView(detail)
            AlertDialog.Builder(this).setTitle("ثبت $title").setView(box)
                .setPositiveButton("ذخیره") { _, _ ->
                    if (name.text.toString().trim().isNotEmpty()) {
                        val arr = load(key)
                        arr.put(JSONObject().put("name", name.text.toString().trim()).put("detail", detail.text.toString().trim()))
                        save(key, arr); showSimpleList(key, title, firstHint, secondHint)
                    }
                }.setNegativeButton("انصراف", null).show()
        })
        val arr = load(key)
        if (arr.length() == 0) c.addView(txt("هنوز موردی ثبت نشده است.", 15f))
        for (i in arr.length() - 1 downTo 0) {
            val o = arr.optJSONObject(i) ?: continue
            addCard(c, o.optString("name"), o.optString("detail")) {
                AlertDialog.Builder(this).setTitle(o.optString("name"))
                    .setMessage("این مورد حذف شود؟")
                    .setPositiveButton("حذف") { _, _ -> arr.remove(i); save(key, arr); showSimpleList(key, title, firstHint, secondHint) }
                    .setNegativeButton("بازگشت", null).show()
            }
        }
        c.addView(btn("بازگشت به صفحه اصلی") { showHome() })
    }

    private fun showInvoices() {
        page = "invoices"
        val c = base("فاکتورها و پیش‌فاکتورها")
        c.addView(btn("＋ ثبت فاکتور چندقلمی") { showInvoiceEditor(null) })
        val arr = load("invoices")
        if (arr.length() == 0) c.addView(txt("هنوز فاکتوری ثبت نشده است."))
        for (i in arr.length() - 1 downTo 0) {
            val o = arr.optJSONObject(i) ?: continue
            val kind = o.optString("kind", "فاکتور")
            val items = o.optJSONArray("items")
            val count = if (items != null) items.length() else 1
            addCard(c, "$kind ${o.optString("number")}  |  ${o.optString("customer")}",
                "${o.optString("date")}  •  ${nf.format(count)} قلم  •  ${money(o.optDouble("total"))}") {
                val details = buildString {
                    append("مشتری: ${o.optString("customer")}\nتاریخ: ${o.optString("date")}\n")
                    if (items != null) {
                        for (j in 0 until items.length()) {
                            val it = items.optJSONObject(j) ?: continue
                            append("\n${j+1}. ${it.optString("description")} — ${nf.format(it.optDouble("qty"))} × ${money(it.optDouble("price"))} = ${money(it.optDouble("lineTotal"))}")
                        }
                    } else append("شرح: ${o.optString("description")}\n")
                    append("\nتخفیف: ${money(o.optDouble("discount"))}\nمبلغ نهایی: ${money(o.optDouble("total"))}")
                }
                AlertDialog.Builder(this).setTitle("$kind ${o.optString("number")}").setMessage(details)
                    .setNeutralButton("ویرایش") { _, _ -> showInvoiceEditor(i) }
                    .setPositiveButton("حذف") { _, _ -> arr.remove(i); save("invoices", arr); showInvoices() }
                    .setNegativeButton("بستن", null).show()
            }
        }
        c.addView(btn("بازگشت به صفحه اصلی") { showHome() })
    }

    private fun showInvoiceEditor(editIndex: Int?) {
        val existing = if (editIndex != null) load("invoices").optJSONObject(editIndex) else null
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(8, 4, 8, 4) }
        val customer = field("نام مشتری", existing?.optString("customer", "") ?: "")
        val kind = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("فاکتور", "پیش‌فاکتور")); setSelection(if (existing?.optString("kind") == "پیش‌فاکتور") 1 else 0) }
        box.addView(txt("نوع سند", 14f, true)); box.addView(kind); box.addView(customer)
        val itemFields = mutableListOf<Triple<EditText, EditText, EditText>>()
        val itemsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun addItem(descValue: String = "", qtyValue: String = "1", priceValue: String = "") {
            val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 6, 0, 6) }
            val desc = field("شرح کالا / خدمات", descValue)
            val qty = field("تعداد", qtyValue)
            qty.inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            val price = field("قیمت واحد (تومان)", priceValue)
            price.inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            row.addView(txt("قلم ${itemFields.size + 1}", 14f, true)); row.addView(desc); row.addView(qty); row.addView(price)
            itemsBox.addView(row)
            itemFields.add(Triple(desc, qty, price))
        }
        val oldItems = existing?.optJSONArray("items")
        if (oldItems != null && oldItems.length() > 0) {
            for (j in 0 until oldItems.length()) {
                val it = oldItems.optJSONObject(j) ?: continue
                addItem(it.optString("description"), it.optDouble("qty", 1.0).toString(), it.optDouble("price", 0.0).toLong().toString())
            }
        } else if (existing != null) addItem(existing.optString("description"), existing.optDouble("qty", 1.0).toString(), existing.optDouble("price", 0.0).toLong().toString()) else addItem()
        box.addView(itemsBox)
        box.addView(btn("＋ افزودن قلم کالا") { addItem() })
        val discount = field("تخفیف کل (تومان)", existing?.optDouble("discount", 0.0)?.toLong()?.toString() ?: "0")
        discount.inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        box.addView(discount)
        val scroll = ScrollView(this).apply { addView(box) }
        AlertDialog.Builder(this).setTitle(if (existing == null) "ثبت سند جدید" else "ویرایش سند").setView(scroll)
            .setPositiveButton("ذخیره") { _, _ ->
                if (customer.text.toString().trim().isEmpty()) { Toast.makeText(this, "نام مشتری را وارد کن", Toast.LENGTH_LONG).show(); return@setPositiveButton }
                val itemArray = JSONArray()
                var subtotal = 0.0
                itemFields.forEach { (d, qf, pf) ->
                    val description = d.text.toString().trim()
                    val q = qf.text.toString().replace(",", "").toDoubleOrNull() ?: 0.0
                    val price = pf.text.toString().replace(",", "").toDoubleOrNull() ?: 0.0
                    if (description.isNotEmpty()) {
                        val line = (q * price).coerceAtLeast(0.0); subtotal += line
                        itemArray.put(JSONObject().put("description", description).put("qty", q).put("price", price).put("lineTotal", line))
                    }
                }
                if (itemArray.length() == 0) { Toast.makeText(this, "حداقل یک قلم کالا وارد کن", Toast.LENGTH_LONG).show(); return@setPositiveButton }
                val disc = (discount.text.toString().replace(",", "").toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0)
                val arr = load("invoices")
                val index = editIndex ?: arr.length()
                val number = existing?.optString("number") ?: (arr.length() + 1).toString()
                val date = existing?.optString("date") ?: SimpleDateFormat("yyyy/MM/dd", Locale("fa")).format(Date())
                val obj = JSONObject().put("number", number).put("kind", kind.selectedItem.toString())
                    .put("customer", customer.text.toString().trim()).put("date", date)
                    .put("items", itemArray).put("discount", disc).put("subtotal", subtotal)
                    .put("total", (subtotal - disc).coerceAtLeast(0.0))
                if (editIndex == null) arr.put(obj) else arr.put(editIndex, obj)
                save("invoices", arr)
                Toast.makeText(this, "سند ذخیره شد: ${money(obj.optDouble("total"))}", Toast.LENGTH_LONG).show()
                showInvoices()
            }.setNegativeButton("انصراف", null).show()
    }

    private fun showReports() {
        val c = base("گزارش فروش")
        val arr = load("invoices")
        var total = 0.0
        for (i in 0 until arr.length()) total += arr.optJSONObject(i)?.optDouble("total", 0.0) ?: 0.0
        c.addView(txt("تعداد فاکتورهای ثبت‌شده: ${nf.format(arr.length())}", 18f, true))
        c.addView(txt("جمع مبلغ فاکتورها: ${money(total)}", 18f, true))
        c.addView(btn("بازگشت") { showHome() })
    }

    private fun showSettings() {
        val c = base("تنظیمات")
        c.addView(txt("الوین فاکتور", 20f, true))
        c.addView(txt("اطلاعات این نسخه به‌صورت محلی روی گوشی ذخیره می‌شود. برای جلوگیری از ازدست‌رفتن داده‌ها، از گوشی پشتیبان بگیرید.", 15f))
        c.addView(btn("خروجی پشتیبان اطلاعات") {
            val backup = JSONObject().put("customers", load("customers")).put("products", load("products")).put("invoices", load("invoices")).toString(2)
            val intent = android.content.Intent(android.content.Intent.ACTION_CREATE_DOCUMENT)
            intent.addCategory(android.content.Intent.CATEGORY_OPENABLE)
            intent.type = "application/json"
            intent.putExtra(android.content.Intent.EXTRA_TITLE, "ElvinFactor-backup.json")
            backupPending = backup
            @Suppress("DEPRECATION")
            startActivityForResult(intent, 77)
        })
        c.addView(btn("بازیابی از فایل پشتیبان JSON") {
            val intent = android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT)
            intent.addCategory(android.content.Intent.CATEGORY_OPENABLE)
            intent.type = "application/json"
            @Suppress("DEPRECATION")
            startActivityForResult(intent, 78)
        })
        c.addView(btn("بازگشت به صفحه اصلی") { showHome() })
    }

    private var backupPending = ""
    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 77 && resultCode == RESULT_OK && data?.data != null) {
            try { contentResolver.openOutputStream(data.data!!)?.use { it.write(backupPending.toByteArray(Charsets.UTF_8)) }
                Toast.makeText(this, "فایل پشتیبان ذخیره شد", Toast.LENGTH_LONG).show()
            } catch (_: Exception) { Toast.makeText(this, "ذخیره پشتیبان ناموفق بود", Toast.LENGTH_LONG).show() }
        } else if (requestCode == 78 && resultCode == RESULT_OK && data?.data != null) {
            try {
                val raw = contentResolver.openInputStream(data.data!!)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: error("empty")
                val backup = JSONObject(raw)
                val editor = prefs.edit()
                listOf("customers", "products", "invoices").forEach { key -> if (backup.has(key)) editor.putString(key, backup.getJSONArray(key).toString()) }
                editor.apply()
                Toast.makeText(this, "بازیابی انجام شد", Toast.LENGTH_LONG).show()
                showHome()
            } catch (_: Exception) { Toast.makeText(this, "فایل پشتیبان معتبر نیست", Toast.LENGTH_LONG).show() }
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (page != "home") showHome() else super.onBackPressed()
    }
}
