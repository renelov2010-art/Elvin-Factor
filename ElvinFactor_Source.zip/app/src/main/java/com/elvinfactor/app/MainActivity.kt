package com.elvinfactor.app

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("elvin_factor", MODE_PRIVATE) }
    private val blue = Color.rgb(22, 79, 135)
    private val pale = Color.rgb(243, 247, 251)
    private val ink = Color.rgb(35, 47, 62)
    private var page = "home"
    private val nf = NumberFormat.getNumberInstance(Locale("fa", "IR"))
    private val persianFont by lazy { try { Typeface.createFromAsset(assets, "fonts/yek_r.ttf") } catch (_: Exception) { Typeface.DEFAULT } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun base(title: String): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(pale)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val header = TextView(this).apply {
            text = title
            textSize = 21f
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
            setPadding(20, 18, 20, 18)
            setBackgroundColor(blue)
        }
        root.addView(header, LinearLayout.LayoutParams(-1, 64))
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 24)
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        return content
    }

    private fun txt(s: String, size: Float = 16f, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = s; textSize = size; setTextColor(ink)
            setTypeface(if (bold) Typeface.create(persianFont, Typeface.BOLD) else persianFont)
            gravity = Gravity.RIGHT
            setPadding(4, 8, 4, 8)
        }

    private fun btn(s: String, action: () -> Unit): Button =
        Button(this).apply {
            text = s; isAllCaps = false
            setTextColor(Color.WHITE); setBackgroundTintList(android.content.res.ColorStateList.valueOf(blue))
            setOnClickListener { action() }
        }

    private fun field(hint: String, value: String = "") = EditText(this).apply {
        this.hint = hint; setText(value); textSize = 16f
        typeface = persianFont
        gravity = Gravity.RIGHT
        setPadding(12, 10, 12, 10)
        layoutDirection = View.LAYOUT_DIRECTION_RTL
    }

    private fun addCard(parent: LinearLayout, title: String, subtitle: String, action: () -> Unit) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 12, 16, 12)
            setBackgroundColor(Color.WHITE)
            elevation = 2f
        }
        card.addView(txt(title, 18f, true))
        card.addView(txt(subtitle, 13f))
        card.setOnClickListener { action() }
        val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = 12
        parent.addView(card, lp)
    }

    private fun load(key: String): JSONArray = try { JSONArray(prefs.getString(key, "[]")) } catch (_: Exception) { JSONArray() }
    private fun save(key: String, arr: JSONArray) { prefs.edit().putString(key, arr.toString()).apply() }
    private fun money(n: Double) = nf.format(n) + " تومان"

    private fun showHome() {
        page = "home"
        val c = base("الوین فاکتور")
        c.addView(txt("مدیریت فروش و فاکتور", 14f))
        val invoices = load("invoices")
        var total = 0.0
        for (i in 0 until invoices.length()) total += invoices.optJSONObject(i)?.optDouble("total", 0.0) ?: 0.0
        val summary = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(16, 12, 16, 12); setBackgroundColor(Color.WHITE)
        }
        summary.addView(txt("تعداد فاکتورها: ${nf.format(invoices.length())}", 17f, true))
        summary.addView(txt("جمع فاکتورها: ${money(total)}", 16f))
        c.addView(summary, LinearLayout.LayoutParams(-1, -2))
        c.addView(txt("دسترسی سریع", 18f, true))
        addCard(c, "🧾  فاکتورها", "ثبت، مشاهده و حذف فاکتورهای ذخیره‌شده") { showInvoices() }
        addCard(c, "👥  مشتریان", "ثبت و نگهداری فهرست مشتریان") { showSimpleList("customers", "مشتریان", "نام مشتری", "شماره تماس") }
        addCard(c, "📦  کالاها و خدمات", "ثبت کالا، قیمت و واحد") { showSimpleList("products", "کالاها و خدمات", "نام کالا", "قیمت واحد") }
        addCard(c, "📊  گزارش فروش", "جمع فروش ثبت‌شده در دستگاه") { showReports() }
        addCard(c, "⚙️  تنظیمات", "اطلاعات و پشتیبان‌گیری") { showSettings() }
        c.addView(txt("نسخه بازسازی‌شده — اطلاعات روی همین گوشی ذخیره می‌شود.", 12f))
    }

    private fun showSimpleList(key: String, title: String, firstHint: String, secondHint: String) {
        page = key
        val c = base(title)
        c.addView(btn("＋ افزودن") {
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(8, 4, 8, 4) }
            val name = field(firstHint)
            val detail = field(secondHint)
            box.addView(name); box.addView(detail)
            AlertDialog.Builder(this).setTitle("ثبت $title").setView(box)
                .setPositiveButton("ذخیره") { _, _ ->
                    if (name.text.toString().trim().isNotEmpty()) {
                        val arr = load(key)
                        arr.put(JSONObject().put("name", name.text.toString().trim()).put("detail", detail.text.toString().trim()))
                        save(key, arr); showSimpleList(key, title, firstHint, secondHint)
                    }
                }.setNegativeButton("انصراف", null).show()
        })
        val arr = load(key)
        if (arr.length() == 0) c.addView(txt("هنوز موردی ثبت نشده است.", 15f))
        for (i in arr.length() - 1 downTo 0) {
            val o = arr.optJSONObject(i) ?: continue
            addCard(c, o.optString("name"), o.optString("detail")) {
                AlertDialog.Builder(this).setTitle(o.optString("name"))
                    .setMessage("این مورد حذف شود؟")
                    .setPositiveButton("حذف") { _, _ -> arr.remove(i); save(key, arr); showSimpleList(key, title, firstHint, secondHint) }
                    .setNegativeButton("بازگشت", null).show()
            }
        }
        c.addView(btn("بازگشت به صفحه اصلی") { showHome() })
    }

    private fun showInvoices() {
        page = "invoices"
        val c = base("فاکتورها و پیش‌فاکتورها")
        c.addView(btn("＋ ثبت فاکتور چندقلمی") { showInvoiceEditor(null) })
        val arr = load("invoices")
        if (arr.length() == 0) c.addView(txt("هنوز فاکتوری ثبت نشده است."))
        for (i in arr.length() - 1 downTo 0) {
            val o = arr.optJSONObject(i) ?: continue
            val kind = o.optString("kind", "فاکتور")
            val items = o.optJSONArray("items")
            val count = if (items != null) items.length() else 1
            addCard(c, "$kind ${o.optString("number")}  |  ${o.optString("customer")}",
                "${o.optString("date")}  •  ${nf.format(count)} قلم  •  ${money(o.optDouble("total"))}") {
                val details = buildString {
                    append("مشتری: ${o.optString("customer")}\nتاریخ: ${o.optString("date")}\n")
                    if (items != null) {
                        for (j in 0 until items.length()) {
                            val it = items.optJSONObject(j) ?: continue
                            append("\n${j+1}. ${it.optString("description")} — ${nf.format(it.optDouble("qty"))} × ${money(it.optDouble("price"))} = ${money(it.optDouble("lineTotal"))}")
                        }
                    } else append("شرح: ${o.optString("description")}\n")
                    append("\nتخفیف: ${money(o.optDouble("discount"))}\nمبلغ نهایی: ${money(o.optDouble("total"))}")
                }
                AlertDialog.Builder(this).setTitle("$kind ${o.optString("number")}").setMessage(details)
                    .setNeutralButton("ویرایش") { _, _ -> showInvoiceEditor(i) }
                    .setPositiveButton("حذف") { _, _ -> arr.remove(i); save("invoices", arr); showInvoices() }
                    .setNegativeButton("بستن", null).show()
            }
        }
        c.addView(btn("بازگشت به صفحه اصلی") { showHome() })
    }

    private fun showInvoiceEditor(editIndex: Int?) {
        val existing = if (editIndex != null) load("invoices").optJSONObject(editIndex) else null
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(8, 4, 8, 4) }
        val customer = field("نام مشتری", existing?.optString("customer", "") ?: "")
        val kind = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("فاکتور", "پیش‌فاکتور")); setSelection(if (existing?.optString("kind") == "پیش‌فاکتور") 1 else 0) }
        box.addView(txt("نوع سند", 14f, true)); box.addView(kind); box.addView(customer)
        val itemFields = mutableListOf<Triple<EditText, EditText, EditText>>()
        val itemsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun addItem(descValue: String = "", qtyValue: String = "1", priceValue: String = "") {
            val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 6, 0, 6) }
            val desc = field("شرح کالا / خدمات", descValue)
            val qty = field("تعداد", qtyValue)
            qty.inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            val price = field("قیمت واحد (تومان)", priceValue)
            price.inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            row.addView(txt("قلم ${itemFields.size + 1}", 14f, true)); row.addView(desc); row.addView(qty); row.addView(price)
            itemsBox.addView(row)
            itemFields.add(Triple(desc, qty, price))
        }
        val oldItems = existing?.optJSONArray("items")
        if (oldItems != null && oldItems.length() > 0) {
            for (j in 0 until oldItems.length()) {
                val it = oldItems.optJSONObject(j) ?: continue
                addItem(it.optString("description"), it.optDouble("qty", 1.0).toString(), it.optDouble("price", 0.0).toLong().toString())
            }
        } else if (existing != null) addItem(existing.optString("description"), existing.optDouble("qty", 1.0).toString(), existing.optDouble("price", 0.0).toLong().toString()) else addItem()
        box.addView(itemsBox)
        box.addView(btn("＋ افزودن قلم کالا") { addItem() })
        val discount = field("تخفیف کل (تومان)", existing?.optDouble("discount", 0.0)?.toLong()?.toString() ?: "0")
        discount.inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        box.addView(discount)
        val scroll = ScrollView(this).apply { addView(box) }
        AlertDialog.Builder(this).setTitle(if (existing == null) "ثبت سند جدید" else "ویرایش سند").setView(scroll)
            .setPositiveButton("ذخیره") { _, _ ->
                if (customer.text.toString().trim().isEmpty()) { Toast.makeText(this, "نام مشتری را وارد کن", Toast.LENGTH_LONG).show(); return@setPositiveButton }
                val itemArray = JSONArray()
                var subtotal = 0.0
                itemFields.forEach { (d, qf, pf) ->
                    val description = d.text.toString().trim()
                    val q = qf.text.toString().replace(",", "").toDoubleOrNull() ?: 0.0
                    val price = pf.text.toString().replace(",", "").toDoubleOrNull() ?: 0.0
                    if (description.isNotEmpty()) {
                        val line = (q * price).coerceAtLeast(0.0); subtotal += line
                        itemArray.put(JSONObject().put("description", description).put("qty", q).put("price", price).put("lineTotal", line))
                    }
                }
                if (itemArray.length() == 0) { Toast.makeText(this, "حداقل یک قلم کالا وارد کن", Toast.LENGTH_LONG).show(); return@setPositiveButton }
                val disc = (discount.text.toString().replace(",", "").toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0)
                val arr = load("invoices")
                val index = editIndex ?: arr.length()
                val number = existing?.optString("number") ?: (arr.length() + 1).toString()
                val date = existing?.optString("date") ?: SimpleDateFormat("yyyy/MM/dd", Locale("fa")).format(Date())
                val obj = JSONObject().put("number", number).put("kind", kind.selectedItem.toString())
                    .put("customer", customer.text.toString().trim()).put("date", date)
                    .put("items", itemArray).put("discount", disc).put("subtotal", subtotal)
                    .put("total", (subtotal - disc).coerceAtLeast(0.0))
                if (editIndex == null) arr.put(obj) else arr.put(editIndex, obj)
                save("invoices", arr)
                Toast.makeText(this, "سند ذخیره شد: ${money(obj.optDouble("total"))}", Toast.LENGTH_LONG).show()
                showInvoices()
            }.setNegativeButton("انصراف", null).show()
    }

    private fun showReports() {
        val c = base("گزارش فروش")
        val arr = load("invoices")
        var total = 0.0
        for (i in 0 until arr.length()) total += arr.optJSONObject(i)?.optDouble("total", 0.0) ?: 0.0
        c.addView(txt("تعداد فاکتورهای ثبت‌شده: ${nf.format(arr.length())}", 18f, true))
        c.addView(txt("جمع مبلغ فاکتورها: ${money(total)}", 18f, true))
        c.addView(btn("بازگشت") { showHome() })
    }

    private fun showSettings() {
        val c = base("تنظیمات")
        c.addView(txt("الوین فاکتور", 20f, true))
        c.addView(txt("اطلاعات این نسخه به‌صورت محلی روی گوشی ذخیره می‌شود. برای جلوگیری از ازدست‌رفتن داده‌ها، از گوشی پشتیبان بگیرید.", 15f))
        c.addView(btn("خروجی پشتیبان اطلاعات") {
            val backup = JSONObject().put("customers", load("customers")).put("products", load("products")).put("invoices", load("invoices")).toString(2)
            val intent = android.content.Intent(android.content.Intent.ACTION_CREATE_DOCUMENT)
            intent.addCategory(android.content.Intent.CATEGORY_OPENABLE)
            intent.type = "application/json"
            intent.putExtra(android.content.Intent.EXTRA_TITLE, "ElvinFactor-backup.json")
            backupPending = backup
            @Suppress("DEPRECATION")
            startActivityForResult(intent, 77)
        })
        c.addView(btn("بازیابی از فایل پشتیبان JSON") {
            val intent = android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT)
            intent.addCategory(android.content.Intent.CATEGORY_OPENABLE)
            intent.type = "application/json"
            @Suppress("DEPRECATION")
            startActivityForResult(intent, 78)
        })
        c.addView(btn("بازگشت به صفحه اصلی") { showHome() })
    }

    private var backupPending = ""
    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 77 && resultCode == RESULT_OK && data?.data != null) {
            try { contentResolver.openOutputStream(data.data!!)?.use { it.write(backupPending.toByteArray(Charsets.UTF_8)) }
                Toast.makeText(this, "فایل پشتیبان ذخیره شد", Toast.LENGTH_LONG).show()
            } catch (_: Exception) { Toast.makeText(this, "ذخیره پشتیبان ناموفق بود", Toast.LENGTH_LONG).show() }
        } else if (requestCode == 78 && resultCode == RESULT_OK && data?.data != null) {
            try {
                val raw = contentResolver.openInputStream(data.data!!)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: error("empty")
                val backup = JSONObject(raw)
                val editor = prefs.edit()
                listOf("customers", "products", "invoices").forEach { key -> if (backup.has(key)) editor.putString(key, backup.getJSONArray(key).toString()) }
                editor.apply()
                Toast.makeText(this, "بازیابی انجام شد", Toast.LENGTH_LONG).show()
                showHome()
            } catch (_: Exception) { Toast.makeText(this, "فایل پشتیبان معتبر نیست", Toast.LENGTH_LONG).show() }
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (page != "home") showHome() else super.onBackPressed()
    }
}
