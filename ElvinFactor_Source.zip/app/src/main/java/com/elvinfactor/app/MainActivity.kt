package com.elvinfactor.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
            setBackgroundColor(Color.rgb(246, 248, 251))
        }

        val title = TextView(this).apply {
            text = "الوین فاکتور"
            textSize = 30f
            setTextColor(Color.rgb(25, 55, 95))
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Elvin Factor\nنسخهٔ اولیه — آماده برای توسعه"
            textSize = 18f
            setTextColor(Color.DKGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 28)
        }
        val note = TextView(this).apply {
            text = "مرحله بعد: طراحی فاکتور، مشتریان، کالاها، گزارش‌ها و پشتیبان‌گیری"
            textSize = 16f
            setTextColor(Color.rgb(70, 80, 95))
            gravity = Gravity.CENTER
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(note)
        setContentView(root)
    }
}
