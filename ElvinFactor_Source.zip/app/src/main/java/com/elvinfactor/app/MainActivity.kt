package com.elvinfactor.app

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("elvin_factor", MODE_PRIVATE) }
    private val blue = Color.rgb(22, 79, 135)
    private val pale = Color.rgb(243, 247, 251)
    private val ink = Color.rgb(35, 47, 62)
    private var page = "home"
    private val nf = NumberFormat.getNumberInstance(Locale("fa", "IR"))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun base(title: String): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(pale)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val header = TextView(this).apply {
            text = title
            textSize = 21f
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
            setPadding(20, 18, 20, 18)
            setBackgroundColor(blue)
        }
        root.addView(header, LinearLayout.LayoutParams(-1, 64))
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 24)
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        return content
    }

    private fun txt(s: String, size: Float = 16f, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = s; textSize = size; setTextColor(ink)
            if (bold) setTypeface(null, Typeface.BOLD)
            gravity = Gravity.RIGHT
            setPadding(4, 8, 4, 8)
        }

    private fun btn(s: String, action: () -> Unit): Button =
        Button(this).apply {
            text = s; isAllCaps = false
            setTextColor(Color.WHITE); setBackgroundTintList(android.content.res.ColorStateList.valueOf(blue))
            setOnClickListener { action() }
        }

    private fun field(hint: String, value: String = "") = EditText(this).apply {
        this.hint = hint; setText(value); textSize = 16f
        gravity = Gravity.RIGHT
        setPadding(12, 10, 12, 10)
        layoutDirection = View.LAYOUT_DIRECTION_RTL
    }

    private fun addCard(parent: LinearLayout, title: String, subtitle: String, action: () -> Unit) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 12, 16, 12)
            setBackgroundColor(Color.WHITE)
            elevation = 2f
        }
        card.addView(txt(title, 18f, true))
        card.addView(txt(subtitle, 13f))
        card.setOnClickListener { action() }
        val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = 12
        parent.addView(card, lp)
    }

    private fun load(key: String): JSONArray = try { JSONArray(prefs.getString(key, "[]")) } catch (_: Exception) { JSONArray() }
    private fun save(key: String, arr: JSONArray) { prefs.edit().putString(key, arr.toString()).apply() }
    private fun money(n: Double) = nf.format(n) + " تومان"

    private fun showHome() {
        page = "home"
        val c = base("الوین فاکتور")
        c.addView(txt("مدیریت فروش و فاکتور", 14f))
        val invoices = load("invoices")
        var total = 0.0
        for (i in 0 until invoices.length()) total += invoices.optJSONObject(i)?.optDouble("total", 0.0) ?: 0.0
        val summary = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(16, 12, 16, 12); setBackgroundColor(Color.WHITE)
        }
        summary.addView(txt("تعداد فاکتورها: ${nf.format(invoices.length())}", 17f, true))
        summary.addView(txt("جمع فاکتورها: ${money(total)}", 16f))
        c.addView(summary, LinearLayout.LayoutParams(-1, -2))
        c.addView(txt("دسترسی سریع", 18f, true))
        addCard(c, "🧾  فاکتورها", "ثبت، مشاهده و حذف فاکتورهای ذخیره‌شده") { showInvoices() }
        addCard(c, "👥  مشتریان", "ثبت و نگهداری فهرست مشتریان") { showSimpleList("customers", "مشتریان", "نام مشتری", "شماره تماس") }
        addCard(c, "📦  کالاها و خدمات", "ثبت کالا، قیمت و واحد") { showSimpleList("products", "کالاها و خدمات", "نام کالا", "قیمت واحد") }
        addCard(c, "📊  گزارش فروش", "جمع فروش ثبت‌شده در دستگاه") { showReports() }
        addCard(c, "⚙️  تنظیمات", "اطلاعات و پشتیبان‌گیری") { showSettings() }
        c.addView(txt("نسخه بازسازی‌شده — اطلاعات روی همین گوشی ذخیره می‌شود.", 12f))
    }

    private fun showSimpleList(key: String, title: String, firstHint: String, secondHint: String) {
        page = key
        val c = base(title)
        c.addView(btn("＋ افزودن") {
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(8, 4, 8, 4) }
            val name = field(firstHint)
            val detail = field(secondHint)
            box.addView(name); box.addView(detail)
            AlertDialog.Builder(this).setTitle("ثبت $title").setView(box)
                .setPositiveButton("ذخیره") { _, _ ->
                    if (name.text.toString().trim().isNotEmpty()) {
                        val arr = load(key)
                        arr.put(JSONObject().put("name", name.text.toString().trim()).put("detail", detail.text.toString().trim()))
                        save(key, arr); showSimpleList(key, title, firstHint, secondHint)
                    }
                }.setNegativeButton("انصراف", null).show()
        })
        val arr = load(key)
        if (arr.length() == 0) c.addView(txt("هنوز موردی ثبت نشده است.", 15f))
        for (i in arr.length() - 1 downTo 0) {
            val o = arr.optJSONObject(i) ?: continue
            addCard(c, o.optString("name"), o.optString("detail")) {
                AlertDialog.Builder(this).setTitle(o.optString("name"))
                    .setMessage("این مورد حذف شود؟")
                    .setPositiveButton("حذف") { _, _ -> arr.remove(i); save(key, arr); showSimpleList(key, title, firstHint, secondHint) }
                    .setNegativeButton("بازگشت", null).show()
            }
        }
        c.addView(btn("بازگشت به صفحه اصلی") { showHome() })
    }

    private fun showInvoices() {
        page = "invoices"
        val c = base("فاکتورها")
        c.addView(btn("＋ ثبت فاکتور جدید") { showNewInvoice() })
        val arr = load("invoices")
        if (arr.length() == 0) c.addView(txt("هنوز فاکتوری ثبت نشده است."))
        for (i in arr.length() - 1 downTo 0) {
            val o = arr.optJSONObject(i) ?: continue
            addCard(c, "${o.optString("number")}  |  ${o.optString("customer")}",
                "${o.optString("date")}  •  ${money(o.optDouble("total"))}") {
                AlertDialog.Builder(this).setTitle("فاکتور ${o.optString("number")}")
                    .setMessage("مشتری: ${o.optString("customer")}\nشرح: ${o.optString("description")}\nمبلغ: ${money(o.optDouble("total"))}")
                    .setPositiveButton("حذف") { _, _ -> arr.remove(i); save("invoices", arr); showInvoices() }
                    .setNegativeButton("بستن", null).show()
            }
        }
        c.addView(btn("بازگشت به صفحه اصلی") { showHome() })
    }

    private fun showNewInvoice() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(8, 4, 8, 4) }
        val customer = field("نام مشتری")
        val desc = field("شرح کالا یا خدمات")
        val qty = field("تعداد", "1")
        val price = field("قیمت واحد (تومان)")
        val discount = field("تخفیف (تومان)", "0")
        listOf(customer, desc, qty, price, discount).forEach { box.addView(it) }
        AlertDialog.Builder(this).setTitle("ثبت فاکتور").setView(box)
            .setPositiveButton("ذخیره فاکتور") { _, _ ->
                val q = qty.text.toString().toDoubleOrNull() ?: 1.0
                val p = price.text.toString().replace(",", "").toDoubleOrNull() ?: 0.0
                val d = discount.text.toString().replace(",", "").toDoubleOrNull() ?: 0.0
                val total = (q * p - d).coerceAtLeast(0.0)
                val arr = load("invoices")
                val date = SimpleDateFormat("yyyy/MM/dd", Locale("fa")).format(Date())
                arr.put(JSONObject().put("number", (arr.length()+1).toString()).put("customer", customer.text.toString())
                    .put("description", desc.text.toString()).put("qty", q).put("price", p)
                    .put("discount", d).put("total", total).put("date", date))
                save("invoices", arr)
                AlertDialog.Builder(this).setTitle("فاکتور ذخیره شد")
                    .setMessage("شماره: ${nf.format(arr.length())}\nمبلغ نهایی: ${money(total)}")
                    .setPositiveButton("تأیید") { _, _ -> showInvoices() }.show()
            }.setNegativeButton("انصراف", null).show()
    }

    private fun showReports() {
        val c = base("گزارش فروش")
        val arr = load("invoices")
        var total = 0.0
        for (i in 0 until arr.length()) total += arr.optJSONObject(i)?.optDouble("total", 0.0) ?: 0.0
        c.addView(txt("تعداد فاکتورهای ثبت‌شده: ${nf.format(arr.length())}", 18f, true))
        c.addView(txt("جمع مبلغ فاکتورها: ${money(total)}", 18f, true))
        c.addView(btn("بازگشت") { showHome() })
    }

    private fun showSettings() {
        val c = base("تنظیمات")
        c.addView(txt("الوین فاکتور", 20f, true))
        c.addView(txt("اطلاعات این نسخه به‌صورت محلی روی گوشی ذخیره می‌شود. برای جلوگیری از ازدست‌رفتن داده‌ها، از گوشی پشتیبان بگیرید.", 15f))
        c.addView(btn("خروجی پشتیبان اطلاعات") {
            val backup = JSONObject().put("customers", load("customers")).put("products", load("products")).put("invoices", load("invoices")).toString(2)
            val intent = android.content.Intent(android.content.Intent.ACTION_CREATE_DOCUMENT)
            intent.addCategory(android.content.Intent.CATEGORY_OPENABLE)
            intent.type = "application/json"
            intent.putExtra(android.content.Intent.EXTRA_TITLE, "ElvinFactor-backup.json")
            backupPending = backup
            @Suppress("DEPRECATION")
            startActivityForResult(intent, 77)
        })
        c.addView(btn("بازگشت به صفحه اصلی") { showHome() })
    }

    private var backupPending = ""
    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 77 && resultCode == RESULT_OK && data?.data != null) {
            try { contentResolver.openOutputStream(data.data!!)?.use { it.write(backupPending.toByteArray(Charsets.UTF_8)) }
                Toast.makeText(this, "فایل پشتیبان ذخیره شد", Toast.LENGTH_LONG).show()
            } catch (_: Exception) { Toast.makeText(this, "ذخیره پشتیبان ناموفق بود", Toast.LENGTH_LONG).show() }
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (page != "home") showHome() else super.onBackPressed()
    }
}
